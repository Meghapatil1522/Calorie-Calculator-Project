# recreate_db.py
import os
import sqlite3

DB = "calorie_db.db"   # अगर तुम्हारा DB नाम अलग है तो यहाँ change करो

# 1) delete old DB if exists
if os.path.exists(DB):
    print("Deleting existing DB:", DB)
    try:
        os.remove(DB)
    except Exception as e:
        print("Could not delete DB:", e)
        raise SystemExit("Stop and close any program using the DB (e.g. Flask server or DB viewer).")

# 2) create new DB with correct tables & columns
print("Creating new DB:", DB)
conn = sqlite3.connect(DB)
c = conn.cursor()

c.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT,
    password TEXT,
    age INTEGER,
    height REAL,
    weight REAL,
    activity_level TEXT
)
''')

c.execute('''
CREATE TABLE IF NOT EXISTS workouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    date TEXT,
    exercise TEXT,
    duration INTEGER,
    calories_burned INTEGER DEFAULT 0
)
''')

c.execute('''
CREATE TABLE IF NOT EXISTS nutrition (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    date TEXT,
    meal TEXT,
    calories INTEGER
)
''')

conn.commit()
conn.close()
print("Database created with tables: users, workouts (with calories_burned), nutrition")
