from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "secret123"
DB_NAME = "calorie_db.db"

# ---------------- Database ----------------
def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def get_db():
    return get_db_connection()

def init_db():
    conn = get_db_connection()

    conn.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        email TEXT NOT NULL,
                        password TEXT NOT NULL,
                        age INTEGER,
                        height REAL,
                        weight REAL,
                        activity_level TEXT
                    )''')

    conn.execute('''CREATE TABLE IF NOT EXISTS workouts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        date TEXT,
                        workout TEXT,
                        duration INTEGER,
                        calories_burned INTEGER
                    )''')

    conn.execute('''CREATE TABLE IF NOT EXISTS nutrition (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        date TEXT,
                        meal TEXT,
                        calories INTEGER
                    )''')

    conn.commit()
    conn.close()

init_db()

# ---------------- Auth ----------------
@app.route('/')
def index():
    if 'user' in session:
        return redirect(url_for('profile'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method=='POST':
        username = request.form['username']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        age = int(request.form['age'])
        height = float(request.form['height'])
        weight = float(request.form['weight'])
        activity_level = request.form['activity_level']

        conn = get_db_connection()
        try:
            conn.execute(
                'INSERT INTO users (username,email,password,age,height,weight,activity_level) VALUES (?,?,?,?,?,?,?)',
                (username,email,password,age,height,weight,activity_level)
            )
            conn.commit()
            conn.close()
            flash("Registration Successful! Please login.", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            flash("Username already exists!", "danger")
            return redirect(url_for('register'))
    return render_template('auth/register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'],password):
            session['user']=user['username']
            session['user_id']=user['id']
            flash("Login Successful!", "success")
            return redirect(url_for('profile'))
        else:
            flash("Invalid username or password!", "danger")
            return redirect(url_for('login'))
    return render_template('auth/login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged Out Successfully.", "info")
    return redirect(url_for('login'))

# ---------------- Profile ----------------
@app.route('/profile')
def profile():
    if 'user' not in session:
        flash("Please login first.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id=?',(user_id,)).fetchone()
    conn.close()

    return render_template('profile.html',user=user)

# ---------------- Dashboard ----------------
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        flash("Please login first.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()

    total_consumed = conn.execute(
        'SELECT SUM(calories) as total FROM nutrition WHERE user_id=?',
        (user_id,)
    ).fetchone()['total'] or 0

    total_burned = conn.execute(
        'SELECT SUM(calories_burned) as total FROM workouts WHERE user_id=?',
        (user_id,)
    ).fetchone()['total'] or 0

    bmi = None
    message = None
    daily_need = 2000

    if user['weight'] and user['height'] and user['age']:
        height_m = user['height'] / 100  
        bmi = round(user['weight'] / (height_m * height_m), 2)

        bmr = 10 * user['weight'] + 6.25 * user['height'] - 5 * user['age'] - 161

        factor = {'Low': 1.2, 'Moderate': 1.55, 'High': 1.725}
        daily_need = int(bmr * factor.get(user['activity_level'], 1.2))

        if bmi < 18.5:
            message = "You are underweight."
        elif 18.5 <= bmi <= 24.9:
            message = "Your weight is normal."
        elif 25 <= bmi <= 29.9:
            message = "You are overweight."
        else:
            message = "You are obese."

    dates = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    calories_consumed = [total_consumed // 7] * 7
    calories_burned = [total_burned // 7] * 7

    conn.close()

    return render_template(
        'dashboard.html',
        user=user,
        bmi=bmi,
        message=message,
        dates=dates,
        calories_consumed=calories_consumed,
        calories_burned=calories_burned,
        daily_calories_needed=daily_need
    )

# ---------------- Workouts ----------------
EXERCISE_CALORIES = {
    "Walking": 4,
    "Running": 11,
    "Cycling": 7,
    "Swimming": 8,
    "Yoga": 3,
    "Gym Workout": 9,
    "Skipping": 10,
    "Dancing": 6,
    "Badminton": 8,
    "Football": 10
}

@app.route('/workouts', methods=['GET','POST'])
def workouts():
    if 'user' not in session:
        flash("Please login first.", "warning")
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    conn = get_db_connection()

    if request.method == 'POST':
        date = request.form['date']
        exercise = request.form['exercise']
        duration = int(request.form['duration'])

        burned = duration * EXERCISE_CALORIES.get(exercise, 0)

        conn.execute(
            'INSERT INTO workouts (user_id,date,workout,duration,calories_burned) VALUES (?,?,?,?,?)',
            (user_id, date, exercise, duration, burned)
        )
        conn.commit()

        flash("Workout Added Successfully!", "success")

    workouts_list = conn.execute(
        'SELECT * FROM workouts WHERE user_id=?',
        (user_id,)
    ).fetchall()

    total_burned = conn.execute(
        'SELECT SUM(calories_burned) as total FROM workouts WHERE user_id=?',
        (user_id,)
    ).fetchone()['total'] or 0

    conn.close()

    return render_template(
        'workouts.html',
        workouts=workouts_list,
        total_burned=total_burned,
        exercise_calories=EXERCISE_CALORIES
    )

# ---------------- Nutrition ----------------
MEAL_CALORIES = {
    "Poha": 100,
    "Oats": 150,
    "Eggs": 70,
    "Chicken": 200,
    "Rice": 130,
    "Roti": 80,
    "Paneer": 100,
    "Dal": 120,
    "Apple": 50,
    "Banana": 80,
    "Pizza": 285,
    "Burger": 295,
    "Fries": 312,
    "Coke": 140,
    "Chocolate": 210
}

@app.route('/nutrition', methods=['GET','POST'])
def nutrition():
    if 'user' not in session:
        flash("Please login first.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_connection()

    if request.method == 'POST':
        date = request.form['date']
        meal = request.form['meal']
        calories = MEAL_CALORIES.get(meal, 0)

        conn.execute(
            'INSERT INTO nutrition (user_id,date,meal,calories) VALUES (?,?,?,?)',
            (user_id,date,meal,calories)
        )
        conn.commit()

        flash("Meal Added Successfully!", "success")

    nutrition_data = conn.execute(
        'SELECT * FROM nutrition WHERE user_id=?',
        (user_id,)
    ).fetchall()

    total_consumed = conn.execute(
        'SELECT SUM(calories) as total FROM nutrition WHERE user_id=?',
        (user_id,)
    ).fetchone()['total'] or 0

    conn.close()

    return render_template(
        'nutrition.html',
        nutrition=nutrition_data,
        total_consumed=total_consumed,
        meal_calories=MEAL_CALORIES
    )

# ---------------- Settings ----------------
# ---------------- Settings ----------------
@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'user_id' not in session:
        flash("Please login first.", "warning")
        return redirect(url_for('login'))

    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],)).fetchone()

    if request.method == "POST":
        try:
            # Safely fetch and convert numeric data
            age = int(request.form.get("age", user["age"]))
            height = float(request.form.get("height", user["height"]))
            weight = float(request.form.get("weight", user["weight"]))
            activity_level = request.form.get("activity_level", user["activity_level"])
            new_password = request.form.get("password")

            # Update user fields
            conn.execute("""
                UPDATE users
                SET age=?, height=?, weight=?, activity_level=?
                WHERE id=?
            """, (age, height, weight, activity_level, session['user_id']))

            # Update password if provided
            if new_password and new_password.strip() != "":
                hashed = generate_password_hash(new_password)
                conn.execute("UPDATE users SET password=? WHERE id=?", (hashed, session['user_id']))

            conn.commit()
            flash("Settings updated successfully!", "success")
            return redirect(url_for('settings'))

        except ValueError:
            flash("Please enter valid numeric values for age, height, and weight.", "danger")
        except Exception as e:
            flash(f"Error updating settings: {str(e)}", "danger")

    conn.close()
    return render_template('settings.html', user=user)


# ---------------- Reports ----------------
@app.route('/reports')
def reports():
    if 'user' not in session:
        flash("Please login first.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_connection()

    workouts = conn.execute(
        'SELECT * FROM workouts WHERE user_id=?',
        (user_id,)
    ).fetchall()

    nutrition = conn.execute(
        'SELECT * FROM nutrition WHERE user_id=?',
        (user_id,)
    ).fetchall()

    total_burned = conn.execute(
        'SELECT SUM(calories_burned) as total FROM workouts WHERE user_id=?',
        (user_id,)
    ).fetchone()['total'] or 0

    total_consumed = conn.execute(
        'SELECT SUM(calories) as total FROM nutrition WHERE user_id=?',
        (user_id,)
    ).fetchone()['total'] or 0

    conn.close()

    return render_template(
        'reports.html',
        workouts=workouts,
        nutrition=nutrition,
        total_burned=total_burned,
        total_consumed=total_consumed
    )

if __name__=="__main__":
    app.run(debug=True)
