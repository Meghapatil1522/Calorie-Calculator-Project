from flask import request
from models.database import get_connection

def save_user_to_db(name, age, gender, height, weight, activity_level):
    connection = get_connection()
    cursor = connection.cursor()

    query = """
    INSERT INTO users (name, age, gender, height, weight, activity_level)
    VALUES (%s, %s, %s, %s, %s, %s)
    """
    values = (name, age, gender, height, weight, activity_level)

    cursor.execute(query, values)
    connection.commit()

    user_id = cursor.lastrowid

    cursor.close()
    connection.close()

    return user_id
