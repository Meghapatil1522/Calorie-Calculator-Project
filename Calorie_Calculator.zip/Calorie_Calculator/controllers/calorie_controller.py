from models.database import get_connection

def save_calorie_log(user_id, calories):
    connection = get_connection()
    cursor = connection.cursor()

    query = """
    INSERT INTO calorie_logs (user_id, calories, date)
    VALUES (%s, %s, CURDATE())
    """
    values = (user_id, calories)

    cursor.execute(query, values)
    connection.commit()

    cursor.close()
    connection.close()


def get_calorie_data(user_id):
    connection = get_connection()
    cursor = connection.cursor()

    query = """
    SELECT date, calories FROM calorie_logs
    WHERE user_id = %s
    ORDER BY date
    """
    cursor.execute(query, (user_id,))
    results = cursor.fetchall()

    dates = [row[0].strftime('%Y-%m-%d') for row in results]
    calories = [row[1] for row in results]

    cursor.close()
    connection.close()

    return dates, calories
